# Danchen CMEZ — GEE Spatial Analysis
Magnesio-Core: 단천 마그네사이트 스마트 경제특구 입지 타당성 분석

> 2026 남북교류와 미래 국토비전 작품 공모전 제출작
> 주최: 대한국토·도시계획학회 / 후원: 국토교통부·통일부

---

## 프로젝트 개요

본 저장소는 함경남도 단천시를 대상으로 한 핵심광물 경제특구(CMEZ: Critical Minerals Economic Zone) 입지 타당성 분석을 위한 Google Earth Engine(GEE) 코드 및 Python 스니펫을 포함합니다.

중국의 마그네슘 공급망 독점(글로벌 점유율 60~80%)에 대응하여, 북한 단천 지역의 마그네사이트 자원(용양광산 확정 매장량 7.7억톤, MgO 45.82%)을 활용한 탈중국 핵심소재 공급망 거점 조성 가능성을 GIS 기반으로 검증합니다.

---

## 파일 구조

```
Magnesio-core-Dancheon/
│
├── README.md                         # 프로젝트 설명
├── .gitignore                        # Git 제외 파일
│
├── 01_basic_visualization.js         # 단천 기본 위성 이미지 + 광산·항만 포인트
├── 02_swir_spectral_analysis.js      # SWIR 분광 분석 (Mg-OH 흡수대)
├── 03_terrain_analysis.js            # DEM 기반 지형·경사도 분석 + 광산권 평탄지 총량
├── 04_flood_risk_analysis.js         # 홍수 리스크 + 가용지 산출 (v2 unmask 보정)
├── 05_export.js                      # GeoTIFF Export (Google Drive)
├── 06_phase1_port_zone.js            # 단천항 5km 1단계 구역 + Zone B/C/E 배치
│
└── python/
    └── zone_b_analysis.py            # 핵심 로직 Python 구현 + Haversine 거리 산출
```

---

## 핵심 분석 결과

> 입지 기준: 단천항 근접(배후 정련단지). 모든 면적은 단천항 포함 단일 AOI 기준.

| 항목 | 수치 | 분석 방법 |
|------|------|---------|
| 용양-대흥 광산 간 거리 | 19.7 km | GEE 거리 계산 |
| AOI 내 전체 가용지 | 121.83 km² | 경사<5° ∩ 홍수500m 제외 |
| 단천항 5km 가용지 (1단계 후보영역) | 11.44 km² | + 단천항 반경 5km |
| Zone B+C+E 1단계 배치 | 1.85 km² | B 0.828 / C 0.613 / E 0.405 |
| Zone B 사이트 경사도 | 1.22도 | NASA SRTM DEM (평탄지) |
| Zone B 사이트 고도 | 2 m | NASA SRTM DEM (항만 배후 평지) |
| Zone B 사이트–단천항 | 4.74 km | Haversine |
| 용양광산 평균 경사도 | 24.2도 | NASA SRTM DEM (광산 급경사) |
| 대흥광산 평균 경사도 | 22.3도 | NASA SRTM DEM (광산 급경사) |

> 포함관계: 121.83 ⊃ 11.44 ⊃ 1.85 ⊃ (B 0.828 + C 0.613 + E 0.405 = 1.846). 검산 일치.
> 광산 인근 평균경사 22~24도는 정련시설 입지에 부적합 → 평탄한 항만 배후권 입지의 GIS 근거.
> 이는 과거 단천 마그네샤연합기업소가 항만권에 입지하여 마그네샤크링카를 생산·수출한 선례와 일치한다.

---

## 수치 정정 이력 (Reproducibility)

본 저장소는 분석의 재현가능성과 자기검증 과정을 투명하게 공개한다.

| 구분 | v1 (초기) | v2 (현재, 확정) |
|------|----------|----------------|
| 입지 기준 | 광산 근접 | 단천항 근접 (배후 정련단지) |
| 대표 면적 | "최종 유효 Zone B 2.19 km²" | 1단계 배치 1.85 km² / 후보영역 11.44 km² |
| 산출 오류 | focal_max 수면 마스크 unmask 누락 → 유효영역 과소산출 | unmask(0) 보정, 검산(평탄지−홍수겹침=가용지) 일치 |
| AOI | 광산권 협역 박스 (31.88 km² 평탄지) | 단천항 포함 확장 박스 (121.83 km² 가용지) |

> "31.88 km²"는 광산권 협역 박스의 경사5도 이하 평탄지 총량으로, 항만 중심 분석과는 AOI가 달라 직접 비교하지 않는다(03_terrain_analysis.js 참조).

---

##  물류 네트워크 거리 (Haversine 산출, WGS84 기준)

| 구간 | 직선거리 | 비고 |
|------|---------|------|
| 용양광산 → 단천항 | 55.2 km | 핵심 물류 루트 |
| 대흥광산 → 단천항 | 74.0 km | |
| 광산 중심점 → 단천항 | 64.6 km | 두 광산 평균 |
| 용양 ↔ 대흥 광산 | 19.8 km | GEE 19.7km와 일치 |

> 평라선 철도 실제 경로는 산악 지형 우회로 직선거리 대비 1.2~1.5배 수준으로 추정.

---

## 대상 지역 좌표

| 지점 | 위도 | 경도 | 출처 |
|------|------|------|------|
| 용양광산 (Ryongyang Mine) | 40.901815°N | 128.804703°E | CSIS Beyond Parallel (2019) |
| 대흥청년영웅광산 (Taehung Mine) | 41.07636°N | 128.84944°E | OpenStreetMap |
| 단천항 (Danchen Port) | 40.412522°N | 128.917731°E | NK Econ Watch (2013) |

---

## 🛠 사용 방법

### GEE JavaScript API

사전 요건
- Google Earth Engine 계정 (Community 등급 이상)
- [GEE Code Editor](https://code.earthengine.google.com) 접속

실행 순서

```
1. code.earthengine.google.com 접속
2. 각 .js 파일 내용을 코드 에디터에 붙여넣기
3. Run 버튼 클릭
4. 05_export.js 실행 후 Tasks 탭에서 Run 클릭
5. Google Drive > GEE_Danchen 폴더에서 결과 확인
```

권장 실행 순서

```
01 → 02 → 03 → 04 → 05
```

### GEE Python API (로컬·Colab)

사전 요건

```bash
pip install earthengine-api
```

실행

```bash
# 최초 1회 인증
earthengine authenticate

# 분석 실행
python python/zone_b_analysis.py
```

주요 출력

```
=== 단천 CMEZ GEE 분석 결과 (v2) ===
AOI 전체 가용지 (경사<5° ∩ 홍수제외): 121.83 km²
단천항 5km 가용지 (1단계 후보영역):   11.44 km²
Zone B+C+E 1단계 배치:               1.85 km²

[고도 분포]
  하위 10%: 827.6 m
  하위 25%: 995.5 m
  중앙값:   1163.5 m

[물류 네트워크 직선거리 — Haversine 산출]
  용양광산 → 단천항:  55.2 km
  대흥광산 → 단천항:  74.0 km
  용양 ↔ 대흥 광산:  19.8 km
```

---

## 데이터 소스

| 데이터 | 출처 | GEE 컬렉션 ID |
|--------|------|--------------|
| 지형 고도(DEM) | NASA SRTM 30m | `USGS/SRTMGL1_003` |
| 위성 이미지 | Landsat 9 Collection 2 | `LANDSAT/LC09/C02/T1_L2` |
| 수면 발생 빈도 | JRC Global Surface Water | `JRC/GSW1_4/GlobalSurfaceWater` |

---

## 📚 참고 문헌

| 자료 | 내용 | URL |
|------|------|-----|
| CSIS Beyond Parallel (2019) | 용양광산 위성 분석 | [링크](https://beyondparallel.csis.org/mining-north-korea-magnesite-production-at-ryongyang-mine/) |
| CSIS Beyond Parallel (2019) | 대흥광산 위성 분석 | [링크](https://beyondparallel.csis.org/mining-north-korea-magnesite-production-at-the-taehung-youth-hero-mine/) |
| NK Econ Watch (2013) | 단천항 준공 현황 | [링크](https://www.nkeconwatch.com/2013/04/25/tanchon-port-reconstruction-to-be-completed-by-2012/) |
| CSIS Beyond Parallel (2018) | 남북 철도 협력 현황 | [링크](https://beyondparallel.csis.org/making-solid-tracks-north-and-south-korean-railway-cooperation/) |
| 통일부 북한정보포털 | 용양광산 매장량·품위 | [링크](https://nkinfo.unikorea.go.kr) |
| USGS Mineral Commodity Summaries | 북한 마그네사이트 매장량 | [링크](https://www.usgs.gov/centers/national-minerals-information-center/mineral-commodity-summaries) |

---

## 한계 및 주의사항

```
1. 북한은 현장 접근 불가 지역으로 모든 분석은
   공개 위성 데이터 기반 원격 탐사 결과임

2. 광산 내부 시설·지하 광맥은 위성 분석으로
   직접 탐지 불가 (지표 분광 분석 기반 간접 추정)

3. 본 분석은 남북관계 호전 및 교류·협력이
   가능한 상황을 전제로 한 정책 기획 목적임

4. 단천항 수심·하역 능력·평라선 철도 상태는
   남북 교류 재개 후 공동 실태조사를 통해 확정 필요

5. 평라선 철도 미매핑 구간은 위성 이미지
   판독 기반 수동 보완 경로이며 추정값임
```

---

## 작성자

- 소속: 강원대학교 부동산학과 / AI데이터과학과
- 공모전: 2026 남북교류와 미래 국토비전 작품 공모전 (학생부문)

---

## 라이선스

본 코드는 학술·연구 목적으로 공개되며 상업적 사용을 금합니다.
