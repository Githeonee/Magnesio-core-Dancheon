/**
 * Magnesio-Core: 단천 CMEZ 입지 타당성 분석
 * Step 04: 홍수 리스크 분석 + 가용지 산출 (v2 — unmask 보정)
 *
 * ───────────────────────────────────────────────────────
 * ※ 수치 정정 이력 (reproducibility 기록)
 *   v1 (초기): "최종 유효 Zone B 2.19 km²"
 *     → focal_max 수면 마스크의 unmask 누락으로 유효영역이
 *        과소산출된 오류. 검산(전체평탄지 − 홍수겹침 ≠ 2.19) 불일치.
 *   v2 (현재): unmask(0) 보정 적용. 입지기준을 광산근접 →
 *        단천항 근접(배후 정련단지)으로 재정의.
 *        → 단천항 5km 가용지 11.44 km², 1단계 배치 1.85 km² 확정.
 *   상세 산출은 06_phase1_port_zone.js 참조.
 * ───────────────────────────────────────────────────────
 *
 * 데이터: NASA SRTM 30m DEM / JRC Global Surface Water v1.4
 */

// 1. 설정 ──────────────────────────────────────────────
var ryongyang = ee.Geometry.Point([128.804703, 40.901815]);
var taehung   = ee.Geometry.Point([128.84944,  41.07636]);
var port      = ee.Geometry.Point([128.917731, 40.412522]);

// 항만 포함 확장 AOI (단천항 40.41N 포함하도록 남측 확장)
var cmezRegion = ee.Geometry.Polygon([[
  [128.75, 40.30], [129.00, 40.30],
  [129.00, 41.13], [128.75, 41.13]
]]);

// 2. DEM + 경사도 ──────────────────────────────────────
var dem       = ee.Image('USGS/SRTMGL1_003').clip(cmezRegion);
var slope     = ee.Terrain.slope(dem);
var hillshade = ee.Terrain.hillshade(dem);
var zoneB     = slope.lt(5);

// 3. JRC 수면 데이터 (★ unmask(0) 보정 — v1 오류 수정 지점) ──
var water = ee.Image('JRC/GSW1_4/GlobalSurfaceWater')
  .select('occurrence').clip(cmezRegion).unmask(0);
var permanentWater = water.gt(50);
var floodZone500   = permanentWater.focal_max({radius:500, units:'meters'}).unmask(0);

// 가용지: 경사<5° AND 홍수 위험 제외
var available = zoneB.and(floodZone500.not());

// 4. 시각화 ────────────────────────────────────────────
Map.centerObject(ee.Geometry.Point([128.90, 40.70]), 10);
Map.addLayer(hillshade, {min:0, max:255}, '음영기복');
Map.addLayer(permanentWater.selfMask(), {palette:['0000FF']}, '상시 수계', false);
Map.addLayer(floodZone500.selfMask(), {palette:['FF6600'], opacity:0.6}, '홍수 고위험(500m)', false);
Map.addLayer(available.selfMask(), {palette:['00FF00']}, '가용지(경사<5°∩홍수제외)');
Map.addLayer(ryongyang, {color:'FF0000'}, '용양광산');
Map.addLayer(taehung,   {color:'FF6600'}, '대흥광산');
Map.addLayer(port,      {color:'0000FF'}, '단천항');

// 5. 면적 계산 ─────────────────────────────────────────
var pxArea = ee.Image.pixelArea();
function km2(mask){
  return mask.multiply(pxArea).rename('a').reduceRegion({
    reducer: ee.Reducer.sum(), geometry: cmezRegion,
    scale: 30, maxPixels: 1e9
  }).getNumber('a').divide(1e6);
}

var flatArea  = km2(zoneB);                       // 전체 평탄지
var availArea = km2(available);                   // 가용지(홍수 제외)
var exclArea  = km2(zoneB.and(floodZone500));     // 평탄지 중 홍수 겹침

// 6. 결과 출력 ─────────────────────────────────────────
print('=== Step 04: 홍수 리스크 + 가용지 (v2 unmask 보정) ===');
print('데이터: JRC Global Surface Water v1.4 (unmask(0) 적용)');
print('');
print('[검산: 전체평탄지 − 홍수겹침 = 가용지 여야 함]');
flatArea.evaluate(function(f){  print('  전체 평탄지(경사<5°): ' + f.toFixed(2) + ' km²'); });
exclArea.evaluate(function(e){  print('  평탄지 중 홍수 겹침 : ' + e.toFixed(2) + ' km²'); });
availArea.evaluate(function(a){
  print('  ★ 가용지(홍수 제외): ' + a.toFixed(2) + ' km²');
  print('');
  print('  ※ 1단계 항만권 구역(단천항 5km) 및 Zone B/C/E 배치는');
  print('     06_phase1_port_zone.js 에서 산출 (11.44 / 1.85 km²)');
});
